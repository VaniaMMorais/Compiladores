import org.antlr.v4.runtime.tree.*;
import static java.lang.System.*;
import java.util.Scanner;
import java.io.*;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import org.stringtemplate.v4.*;

import error.ErrorHandling;


public class DimanaMain {
   public static void main(String[] args) {
      CharStream input =null;
      try{
         //read file
         input = CharStreams.fromStream(new FileInputStream(args[0]));
      }
      catch(Exception e){
         ErrorHandling.printError("Couldn't find the file \"" + args[0] + "\"");
         System.exit(1);
      }
   
      // create a lexer that feeds off of input CharStream:
      DimanaLexer lexer = new DimanaLexer(input);
      // create a buffer of tokens pulled from the lexer:
      CommonTokenStream tokens = new CommonTokenStream(lexer);
      // create a parser that feeds off the tokens buffer:
      DimanaParser parser = new DimanaParser(tokens);
      // replace error listener:
      //parser.removeErrorListeners(); // remove ConsoleErrorListener
      //parser.addErrorListener(new ErrorHandlingListener());
      // begin parsing at main rule:
      ParseTree tree = parser.program();
      if (parser.getNumberOfSyntaxErrors() == 0) {

         CheckDimana visitor0 = new CheckDimana();
         visitor0.visit(tree);
         if(!ErrorHandling.error()){
            Compiler compiler = new Compiler();
            String outputLang = "java";
            // if (!compiler.validTarget(outputLang)) {
            //    ErrorHandling.printError("Can't find template group file for " + outputLang);
            //    System.exit(1);
            // }
            //compiler.setTarget(outputLang);
            ST code = compiler.visit(tree);

            String outputFileName = "Output";

            String outputFileExtension =  "." + outputLang;

            String outputFile = outputFileName + outputFileExtension;

            try {
               code.add("name", outputFileName);
               PrintWriter pw = new PrintWriter(new File(outputFile));
               pw.print(code.render());
               pw.close();

            } catch (FileNotFoundException e) {
               System.err.println("Could not write code to the file");
               System.exit(1);
            }
      }
   }
   }
}

// public class DimanaMain {
//    public static void main(String[] args) {
//       try{
//          CharStream input = CharStreams.fromFileName(args[0]);
//          File f = new File(args[0]);
//          DimanaLexer lexer = new DimanaLexer(input);
//          CommonTokenStream tokens = new CommonTokenStream(lexer);
//          DimanaParser parser = new DimanaParser(tokens);
//          ParseTree tree = parser.program();
//          if (parser.getNumberOfSyntaxErrors() == 0) {
//             CheckDimana semanticCheck = new CheckDimana();
//             Compiler compiler = new Compiler();
//             semanticCheck.visit(tree);

//             if (!ErrorHandling.error()) {
//               try {
//                  ST result = compiler.visit(tree);
//                  String file = "Output.java";

//                  result.add("name", "Output");
//                  System.out.println(result.render());
//                  PrintWriter pw = new PrintWriter(new File(file));
//                  pw.print(result.render());
//                  pw.close();

//               } catch (FileNotFoundException e) {
//                  System.err.println("Não conseguiu escrever no ficheiro");
//                  System.exit(1);
//               }

//             }
//             ST result = compiler.visit(tree);
//             result.add("name", "Output");
//             System.out.println(result.render());
//             String file = "pdraw.java";
//             PrintWriter pw = new PrintWriter(new File(file));
//             pw.print(result.render());
//             pw.close();

//          }
//       } catch (IOException e) {
//          e.printStackTrace();
//          System.exit(1);
//       } catch (RecognitionException e) {
//          e.printStackTrace();
//          System.exit(1);
//       }
      

//       //try {
//       //   Scanner sc = new Scanner(System.in);
//       //   String lineText = null;
//       //   int numLine = 1;
//       //   if (sc.hasNextLine())
//       //      lineText = sc.nextLine();
//       //   DimanaParser parser = new DimanaParser(null);
//       //   // replace error listener:
//       //   //parser.removeErrorListeners(); // remove ConsoleErrorListener
//       //   //parser.addErrorListener(new ErrorHandlingListener());
//       //   Compiler visitor0 = new Compiler();
//       //   while(lineText != null) {
//       //      // create a CharStream that reads from standard input:
//       //      CharStream input = CharStreams.fromString(lineText + "\n");
//       //      // create a lexer that feeds off of input CharStream:
//       //      DimanaLexer lexer = new DimanaLexer(input);
//       //      lexer.setLine(numLine);
//       //      lexer.setCharPositionInLine(0);
//       //      // create a buffer of tokens pulled from the lexer:
//       //      CommonTokenStream tokens = new CommonTokenStream(lexer);
//       //      // create a parser that feeds off the tokens buffer:
//       //      parser.setInputStream(tokens);
//       //      // begin parsing at program rule:
//       //      ParseTree tree = parser.program();
//       //      if (parser.getNumberOfSyntaxErrors() == 0) {
//       //         // print LISP-style tree:
//       //         // System.out.println(tree.toStringTree(parser));
//       //         visitor0.visit(tree);
//       //      }
//       //      if (sc.hasNextLine())
//       //         lineText = sc.nextLine();
//       //      else
//       //         lineText = null;
//       //      numLine++;
//       //   }
//       //}
//       //catch(RecognitionException e) {
//       //   e.printStackTrace();
//       //   System.exit(1);
//       //}
//    }
// }
