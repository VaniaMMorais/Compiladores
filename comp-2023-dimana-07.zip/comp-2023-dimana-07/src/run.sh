#!/bin/bash
javac Output.java
java Output