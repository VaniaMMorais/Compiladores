
import java.util.ArrayList;
import java.util.HashMap;
import java.text.ParseException;
import java.util.Iterator;

import error.ErrorHandling;
@SuppressWarnings("CheckReturnValue")
public class DimCheck extends DimensionsBaseVisitor<Object> {

   @Override public Object visitProgram(DimensionsParser.ProgramContext ctx) {
      Object res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public Object visitInstruction(DimensionsParser.InstructionContext ctx) {
      Object res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public Object visitDimensionSi(DimensionsParser.DimensionSiContext ctx) {
      boolean validation = true;
      String name = ctx.ID(0).getText();//length
      String unit = ctx.ID(1).getText();//meter
      String tipo = ctx.type.getText();//real
      String sufix = "";

      if (DimensionsParser.medida.containsKey(unit) || DimensionsParser.unidade.containsValue(unit) || DimensionsParser.unidadeSuf.containsValue(unit)|| DimensionsParser.unidadeSuf.containsKey(unit)) {
         ErrorHandling.printError("A variavel "+unit+" ja existe");
         validation = false;
      }
      
      
      if(DimensionsParser.unidade.containsValue(name) || DimensionsParser.medida.containsKey(name) ){
         ErrorHandling.printError("A variavel "+name+" ja existe");
         validation = false;
      }

      if (!Character.isUpperCase(name.charAt(0))) {
         ErrorHandling.printError("A variavel "+name+" deve inicializar com letra maiuscula");
         validation = false;
      }

      if(validation){
         DimensionsParser.unidade.put(name,unit);
         DimensionsParser.medida.put(name,tipo);
         if (  ctx.ID().size()==3 ) {
            sufix = ctx.ID(2).getText();
            if (DimensionsParser.unidadeSuf.containsKey(sufix)) {
               ErrorHandling.printError("este sufixo ja existe");
               validation = false;
            }else{
               DimensionsParser.unidadeSuf.put(sufix,unit);
            }
         }
      
      }


      return validation;
   }

   @Override public Object visitDimensionDependant(DimensionsParser.DimensionDependantContext ctx) {
      boolean validation = true;
      String name = ctx.ID(0).getText();
      String tipo = ctx.type.getText();

      ArrayList<String> expr= new ArrayList<String>();
      if (DimensionsParser.medida.containsKey(name)) {
         validation = false;
         ErrorHandling.printError("esta medida ja existe");
      }else{
         for(int i=0;i<ctx.OP().size();i++){
            expr.add(ctx.ID(i+1).getText());
            expr.add(ctx.OP(i).getText());
         }
         expr.add(ctx.ID(ctx.OP().size()+1).getText());
         for (String token : expr) {
            if(!(token.equals("*") || token.equals("/") || DimensionsParser.medida.containsKey(token))){
               validation=false;
               ErrorHandling.printError("a medida "+token+" nao esta definida");
            }
               
         }
         if (validation) {
            DimensionsParser.medida.put(name,tipo);
            DimensionsParser.dependentExpr.put(name,expr);
         }

      }
      return validation;
   }

   @Override public Object visitPrefix(DimensionsParser.PrefixContext ctx) {
      boolean validation = true;
      String name = ctx.ID().getText();
      String nota= String.valueOf( visit(ctx.notacao()));

      if (name.length() != 1) {
         validation=false;
         ErrorHandling.printError("Prefixos so devem ter um caracter");
      } 
      if(DimensionsParser.medida.containsKey(name) || DimensionsParser.unidadeSuf.containsKey(name) || DimensionsParser.unidadeSuf.containsValue(name)){
         validation=false;
         ErrorHandling.printError("A variavel "+name+" ja esta a ser utilizada");
      }
      
      if(validation){
         Double valor=10.0;
         String cienc=nota;
         if (nota == "10")
            DimensionsParser.prefixos.put(name, 10.0);
         else{
            cienc=cienc.replace("e", "");
            DimensionsParser.prefixos.put(name,Math.pow(10,Double.parseDouble(cienc)));
         }
      }

      return validation;
   }

   @Override public String visitUnit(DimensionsParser.UnitContext ctx) {
      boolean validation = true;
      String name = ctx.classe.getText();
      String unit = ctx.ID(1).getText();
      Double valor = Double.parseDouble(ctx.REAL().getText()) ;
      String newclasse = ctx.newclass.getText();
      //System.out.println(ctx.OP().getText());
      if (!DimensionsParser.unidade.containsKey(name)) {
         validation=false;
         ErrorHandling.printError("A medida "+name+" nao existe");
      }else if(!DimensionsParser.unidade.get(name).equals(newclasse) ){
         validation=false;
         ErrorHandling.printError("A medida "+name+" nao é "+ newclasse);
         if (DimensionsParser.unidadeSuf.containsKey(unit) || DimensionsParser.unidadeSuf.containsValue(unit) || DimensionsParser.medida.containsKey(unit)) {
            validation=false;
            ErrorHandling.printError("A unidade "+unit+" ja esta a ser usada ");
         }
      
      }




      if (validation) {
         HashMap<String,Double> aux= new HashMap<String,Double>();
         if (  ctx.ID().size()==4 ) {
            String unit2 = ctx.ID(2).getText();
            DimensionsParser.unidadeSuf.put(unit2, unit);
         }
         if (DimensionsParser.alternative.containsKey(name)) {
            aux=DimensionsParser.alternative.get(name);
         }
   
         aux.put(unit,valor);
         DimensionsParser.alternative.put(name,aux);
         
      }

      return "sucess";
   }

   @Override public String visitNotacaodez(DimensionsParser.NotacaodezContext ctx) {
      return "10";
      //return res;
   }

   @Override public String visitNotacaocienfitica(DimensionsParser.NotacaocienfiticaContext ctx) {
      String mul = ctx.INT().getText();
      return "e"+mul;
      //return res;
   }
}
