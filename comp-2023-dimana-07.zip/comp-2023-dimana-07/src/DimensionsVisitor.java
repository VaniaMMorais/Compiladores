// Generated from Dimensions.g4 by ANTLR 4.9.3



import java.util.HashMap;
import java.util.ArrayList;
import java.util.List;

import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link DimensionsParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface DimensionsVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link DimensionsParser#program}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProgram(DimensionsParser.ProgramContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionsParser#instruction}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInstruction(DimensionsParser.InstructionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code dimensionSi}
	 * labeled alternative in {@link DimensionsParser#dimension}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDimensionSi(DimensionsParser.DimensionSiContext ctx);
	/**
	 * Visit a parse tree produced by the {@code dimensionDependant}
	 * labeled alternative in {@link DimensionsParser#dimension}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDimensionDependant(DimensionsParser.DimensionDependantContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionsParser#prefix}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrefix(DimensionsParser.PrefixContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimensionsParser#unit}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnit(DimensionsParser.UnitContext ctx);
	/**
	 * Visit a parse tree produced by the {@code notacaodez}
	 * labeled alternative in {@link DimensionsParser#notacao}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNotacaodez(DimensionsParser.NotacaodezContext ctx);
	/**
	 * Visit a parse tree produced by the {@code notacaocienfitica}
	 * labeled alternative in {@link DimensionsParser#notacao}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNotacaocienfitica(DimensionsParser.NotacaocienfiticaContext ctx);
}