class Dim{
    
    Double value;
    String unit;

    Dim(Double value, String unit){
        value = this.value;
        unit = this.unit;
    }

    Dim div(Dim other){
        if (value == 0){
            throw new IllegalArgumentException("Cannot divide by zero");
        } 
        else if(other.unit.equals(unit)){
            return new Dim(other.value/value, other.unit);
        }
        return new Dim(other.value/value, other.unit + "/" + unit);
    }

    Dim mul(Dim other){
        if(other.unit.equals(unit)){
            return new Dim(other.value/value, other.unit);
        }
        return new Dim(other.value*value, other.unit + "." + unit);
    }

    Dim sum(Dim other){
        if (!other.unit.equals(unit)){
            throw new IllegalArgumentException("Units are not the same");
        }
        return new Dim(other.value+value, other.unit);
    }

    Dim sub(Dim other){
        if (!other.unit.equals(unit)){
            throw new IllegalArgumentException("Units are not the same");
        }
        return new Dim(other.value-value, other.unit);
    }

}