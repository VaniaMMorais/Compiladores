// Generated from Dimana.g4 by ANTLR 4.9.3
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link DimanaParser}.
 */
public interface DimanaListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link DimanaParser#program}.
	 * @param ctx the parse tree
	 */
	void enterProgram(DimanaParser.ProgramContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimanaParser#program}.
	 * @param ctx the parse tree
	 */
	void exitProgram(DimanaParser.ProgramContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimanaParser#instruction}.
	 * @param ctx the parse tree
	 */
	void enterInstruction(DimanaParser.InstructionContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimanaParser#instruction}.
	 * @param ctx the parse tree
	 */
	void exitInstruction(DimanaParser.InstructionContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimanaParser#write}.
	 * @param ctx the parse tree
	 */
	void enterWrite(DimanaParser.WriteContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimanaParser#write}.
	 * @param ctx the parse tree
	 */
	void exitWrite(DimanaParser.WriteContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimanaParser#use}.
	 * @param ctx the parse tree
	 */
	void enterUse(DimanaParser.UseContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimanaParser#use}.
	 * @param ctx the parse tree
	 */
	void exitUse(DimanaParser.UseContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimanaParser#init}.
	 * @param ctx the parse tree
	 */
	void enterInit(DimanaParser.InitContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimanaParser#init}.
	 * @param ctx the parse tree
	 */
	void exitInit(DimanaParser.InitContext ctx);
	/**
	 * Enter a parse tree produced by the {@code assignExpr}
	 * labeled alternative in {@link DimanaParser#assign}.
	 * @param ctx the parse tree
	 */
	void enterAssignExpr(DimanaParser.AssignExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code assignExpr}
	 * labeled alternative in {@link DimanaParser#assign}.
	 * @param ctx the parse tree
	 */
	void exitAssignExpr(DimanaParser.AssignExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code listExpr}
	 * labeled alternative in {@link DimanaParser#assign}.
	 * @param ctx the parse tree
	 */
	void enterListExpr(DimanaParser.ListExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code listExpr}
	 * labeled alternative in {@link DimanaParser#assign}.
	 * @param ctx the parse tree
	 */
	void exitListExpr(DimanaParser.ListExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code listAddExpr}
	 * labeled alternative in {@link DimanaParser#assign}.
	 * @param ctx the parse tree
	 */
	void enterListAddExpr(DimanaParser.ListAddExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code listAddExpr}
	 * labeled alternative in {@link DimanaParser#assign}.
	 * @param ctx the parse tree
	 */
	void exitListAddExpr(DimanaParser.ListAddExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimanaParser#ifStatement}.
	 * @param ctx the parse tree
	 */
	void enterIfStatement(DimanaParser.IfStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimanaParser#ifStatement}.
	 * @param ctx the parse tree
	 */
	void exitIfStatement(DimanaParser.IfStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimanaParser#forStatement}.
	 * @param ctx the parse tree
	 */
	void enterForStatement(DimanaParser.ForStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimanaParser#forStatement}.
	 * @param ctx the parse tree
	 */
	void exitForStatement(DimanaParser.ForStatementContext ctx);
	/**
	 * Enter a parse tree produced by the {@code indexExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterIndexExpr(DimanaParser.IndexExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code indexExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitIndexExpr(DimanaParser.IndexExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code stringExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterStringExpr(DimanaParser.StringExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code stringExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitStringExpr(DimanaParser.StringExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code unaryExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterUnaryExpr(DimanaParser.UnaryExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code unaryExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitUnaryExpr(DimanaParser.UnaryExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code intExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterIntExpr(DimanaParser.IntExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code intExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitIntExpr(DimanaParser.IntExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code convExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterConvExpr(DimanaParser.ConvExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code convExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitConvExpr(DimanaParser.ConvExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code realExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterRealExpr(DimanaParser.RealExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code realExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitRealExpr(DimanaParser.RealExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code readExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterReadExpr(DimanaParser.ReadExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code readExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitReadExpr(DimanaParser.ReadExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code mulDivExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterMulDivExpr(DimanaParser.MulDivExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code mulDivExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitMulDivExpr(DimanaParser.MulDivExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code sumSubExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterSumSubExpr(DimanaParser.SumSubExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code sumSubExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitSumSubExpr(DimanaParser.SumSubExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code parenExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterParenExpr(DimanaParser.ParenExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code parenExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitParenExpr(DimanaParser.ParenExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code idExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterIdExpr(DimanaParser.IdExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code idExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitIdExpr(DimanaParser.IdExprContext ctx);
}