// Generated from Dimana.g4 by ANTLR 4.9.3
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link DimanaParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface DimanaVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link DimanaParser#program}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProgram(DimanaParser.ProgramContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimanaParser#instruction}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInstruction(DimanaParser.InstructionContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimanaParser#write}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWrite(DimanaParser.WriteContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimanaParser#use}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUse(DimanaParser.UseContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimanaParser#init}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInit(DimanaParser.InitContext ctx);
	/**
	 * Visit a parse tree produced by the {@code assignExpr}
	 * labeled alternative in {@link DimanaParser#assign}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssignExpr(DimanaParser.AssignExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code listExpr}
	 * labeled alternative in {@link DimanaParser#assign}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitListExpr(DimanaParser.ListExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code listAddExpr}
	 * labeled alternative in {@link DimanaParser#assign}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitListAddExpr(DimanaParser.ListAddExprContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimanaParser#ifStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIfStatement(DimanaParser.IfStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link DimanaParser#forStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitForStatement(DimanaParser.ForStatementContext ctx);
	/**
	 * Visit a parse tree produced by the {@code indexExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIndexExpr(DimanaParser.IndexExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code stringExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStringExpr(DimanaParser.StringExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code unaryExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryExpr(DimanaParser.UnaryExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code intExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIntExpr(DimanaParser.IntExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code convExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConvExpr(DimanaParser.ConvExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code realExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRealExpr(DimanaParser.RealExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code readExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReadExpr(DimanaParser.ReadExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code mulDivExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMulDivExpr(DimanaParser.MulDivExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code sumSubExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSumSubExpr(DimanaParser.SumSubExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code parenExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParenExpr(DimanaParser.ParenExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code idExpr}
	 * labeled alternative in {@link DimanaParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdExpr(DimanaParser.IdExprContext ctx);
}