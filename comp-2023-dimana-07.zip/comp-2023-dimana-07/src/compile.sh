#!/bin/bash
while getopts u: flag
do
    case "${flag}" in
        u) filename=${OPTARG};;
    esac
done

java DimanaMain $filename