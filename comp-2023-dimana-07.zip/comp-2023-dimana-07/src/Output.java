import java.util.*;
import java.util.Scanner;

public class Output {
    static Object conv(String var, String value, Object intValue){
        if (var.equals("integer")) {
            return Integer.parseInt(value);
        } else if (var.equals("real")) {
            return Double.parseDouble(value);
        } else {
            if (intValue != null) {
                return String.format("%d", value, intValue);
            } else {
                return String.format("%d", value);
            }
        }
    }

    static Object conv(String var, String value){
        return conv(var, value, null);
    }


    static String read(String msg){
        Scanner read = new Scanner(System.in);
        System.out.printf(msg);
        return read.nextLine(); 
    }

    public static void main(String[] args) {
        Medida n  = new Medida("NMEC")    ;
        String name ;
        Medida g  = new Medida("Grade")    ;
        n =  conv("integer", read("NMEC: ") )*(nmec )  ;
        name = read("Name: ") ;
        g =  conv("real", read("Grade: ") )*(val )  ;
        System.out.printf(conv("string", "NMEC:" , 10) + " ");
        System.out.printf(conv("string", "NMEC:" ) + " ");
        System.out.printf(conv("string", "Name" , 30) + " ");
        System.out.printf(conv("string", "Grade:" , 10) + " ");
        System.out.printf(conv("string",  n  , 10) + " " +conv("string",  name  , 30) + " " +conv("string",  g  , 10) + " ");
    }
}