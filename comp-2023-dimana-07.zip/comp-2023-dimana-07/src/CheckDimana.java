import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.Map;
import java.io.*;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;

import error.ErrorHandling;


import org.antlr.v4.runtime.ParserRuleContext;

public class CheckDimana extends DimanaBaseVisitor<Boolean> {

   @Override public Boolean visitProgram(DimanaParser.ProgramContext ctx) {
      Iterator <DimanaParser.InstructionContext> iter = ctx.instruction().iterator();
      Boolean res=true;
      while(iter.hasNext()){
         res=visit(iter.next());
      }

      return res;
   }

   @Override public Boolean visitInstruction(DimanaParser.InstructionContext ctx) {
      Boolean validation = true;
    
      if (ctx.use() != null) {
          validation = visitUse(ctx.use());
      }
      
      if (validation) {
         int childCount = ctx.getChildCount();
         for (int i = 0; i < childCount; i++) {
             ParseTree child = ctx.getChild(i);
             if (child instanceof DimanaParser.InstructionContext) {
                 validation = visitInstruction((DimanaParser.InstructionContext) child);
                 if (!validation) {
                     break;
                 }
             }
         }
     }
      
      return validation;
   //    Boolean validation=true;
      
   //    if(ctx.use()!=null){
   //       Iterator<DimanaParser.UseContext> it = ctx.use().iterator();       
   //       while(it.hasNext()){
   //          validation = visit(it.next());
   //       }
   //    }
   //    if(validation){
   //       if(ctx.instruction() !=null){
   //          validation= visit(ctx.instruction());
   //       }
          
   //    }
     
   //   return validation;
   }

   @Override public Boolean visitWrite(DimanaParser.WriteContext ctx) {
      boolean validation = true;

      for (DimanaParser.ExprContext exprCtx : ctx.expr()) {
          validation &= visit(exprCtx);
      }

      return validation;
   }

   @Override public Boolean visitUse(DimanaParser.UseContext ctx) {
      Boolean validation = true;
      String fileName = ctx.STRING().getText();
      fileName = fileName.substring(1, fileName.length() - 1);
      InputStream in_stream = null;
      CharStream input = null;
      try {
          in_stream = new FileInputStream(new File(fileName));
          //instead of reading from user input, reads from file input
          input = CharStreams.fromStream(in_stream);
          //System.out.println(input.toString());
      } catch (IOException e) {
          ErrorHandling.printError(ctx, "ERROR: reading file \"" + fileName + "\"");
          validation = false;
      } finally {
          if (in_stream != null) {
              try {
                  in_stream.close();
              } catch (IOException e) {
                  // Handle error while closing the stream if needed
              }
          }
      }

      if (validation) {
          DimensionsLexer lexer = new DimensionsLexer(input);
          CommonTokenStream tokens = new CommonTokenStream(lexer);
          DimensionsParser parser = new DimensionsParser(tokens);
          ParseTree tree = parser.program();
          
          

          if (parser.getNumberOfSyntaxErrors() == 0) {
              DimCheck visitor1 = new DimCheck();
              visitor1.visit(tree);
          }
          System.out.println(parser.medida);
      }
      
      return validation;
   }

   @Override public Boolean visitInit(DimanaParser.InitContext ctx) {
      Boolean res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public Boolean visitAssignExpr(DimanaParser.AssignExprContext ctx) {
      Boolean res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public Boolean visitListExpr(DimanaParser.ListExprContext ctx) {
      Boolean res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public Boolean visitListAddExpr(DimanaParser.ListAddExprContext ctx) {
      Boolean res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public Boolean visitIfStatement(DimanaParser.IfStatementContext ctx) {
      Boolean res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public Boolean visitForStatement(DimanaParser.ForStatementContext ctx) {
      Boolean res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public Boolean visitIndexExpr(DimanaParser.IndexExprContext ctx) {
      Boolean res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public Boolean visitStringExpr(DimanaParser.StringExprContext ctx) {
      Boolean res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public Boolean visitUnaryExpr(DimanaParser.UnaryExprContext ctx) {
      Boolean res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public Boolean visitIntExpr(DimanaParser.IntExprContext ctx) {
      Boolean res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public Boolean visitConvExpr(DimanaParser.ConvExprContext ctx) {
      Boolean res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public Boolean visitRealExpr(DimanaParser.RealExprContext ctx) {
      Boolean res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public Boolean visitReadExpr(DimanaParser.ReadExprContext ctx) {
      Boolean res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public Boolean visitMulDivExpr(DimanaParser.MulDivExprContext ctx) {
      Boolean res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public Boolean visitSumSubExpr(DimanaParser.SumSubExprContext ctx) {
      Boolean res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public Boolean visitParenExpr(DimanaParser.ParenExprContext ctx) {
      Boolean res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public Boolean visitIdExpr(DimanaParser.IdExprContext ctx) {
      Boolean res = null;
      return visitChildren(ctx);
      //return res;
   }
}
