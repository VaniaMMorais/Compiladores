import org.stringtemplate.v4.*;
import java.util.*;

import javax.print.DocFlavor.STRING;

@SuppressWarnings("CheckReturnValue")
public class Compiler extends DimanaBaseVisitor<ST> {

   Map <String,Boolean> variables = new HashMap<String,Boolean> ();
   STGroup group = new STGroupFile("template.stg");

   @Override public ST visitProgram(DimanaParser.ProgramContext ctx) {

      ST beginTemplate = group.getInstanceOf("begin");

      // Visitar as instruções e adicionar o corpo ao template "begin"
      List<ST> bodyStatements = new ArrayList<>();
      for (DimanaParser.InstructionContext instructionContext : ctx.instruction()) {
          ST statementTemplate = visit(instructionContext);
          bodyStatements.add(statementTemplate);
      }
      beginTemplate.add("body", bodyStatements);

      // Renderizar o template "begin" e retornar
      return beginTemplate;
      // ST st;
      // String result = "";
      // st = group.getInstanceOf("begin");

      // visitChildren(ctx);

      // // st = group.getInstanceOf("end");
      // result += st.render();

      // System.out.println(result);
      // return null;
   }

   @Override public ST visitInstruction(DimanaParser.InstructionContext ctx) {
      ST res = null;
      return visitChildren(ctx);
      //return res;
   }

   @Override public ST visitWrite(DimanaParser.WriteContext ctx) {
      //ST result = new ST(""); // Cria uma nova instância de ST vazia
      ST st = group.getInstanceOf("write");
      for (DimanaParser.ExprContext exprCtx : ctx.expr()) {
         if (exprCtx instanceof DimanaParser.StringExprContext) {
            System.out.println("STRING");
             String stringValue = exprCtx.getText();
             st.add("e", stringValue);
         } else {
             ST e = visit(exprCtx);
             st.add("e", e.render());
         }
          //result.add("write", st.render()); // Adiciona o resultado renderizado da instrução st à instância result
      }
  
      return st;
   }

   // @Override public ST visitUse(DimanaParser.UseContext ctx) {
   //    ST st = group.getInstanceOf("use");
   //    String e1 = ctx.getText(); // Obter o texto completo do contexto
   //    st.add("e1", e1);
   //    return st;
   // }

   @Override public ST visitInit(DimanaParser.InitContext ctx) {
      String type = ctx.ID(0).getText();
      String e = ctx.ID(1).getText();
      ST st = group.getInstanceOf("init");
      
      if (type.equals("integer")) {
         ST su = group.getInstanceOf("initP");
         type = "int";
         su.add("var", type);

         su.add("e", e);
         return su;
      } else if (type.equals("real")) {
         ST su = group.getInstanceOf("initP");
         type = "double";
         su.add("var", type);

         su.add("e", e);
         return su;
      } else if (type.equals("string")) {
         ST su = group.getInstanceOf("initP");
         type = "String";
         su.add("var", type);

         su.add("e", e);
         return su;
      }else{
         System.out.println(DimensionsParser.unidade.get(type));
      }
      
      st.add("var", type);

      st.add("e", e);
      return st;
   }

   @Override public ST visitIfStatement(DimanaParser.IfStatementContext ctx) {
      ST st = group.getInstanceOf("ifStatement");
      ST e = visit(ctx.expr());
      st.add("condition", e);
      if(ctx.instruction().size() == 1){
         ST e1 = visit(ctx.instruction(0));
         st.add("codeTrue", e1);
      }
      else{
         ST e1 = visit(ctx.instruction(0));
         ST e2 = visit(ctx.instruction(1));
         st.add("codeTrue", e1);
         st.add("codeFalse", e2);
      }
      return st;
   }

   @Override public ST visitForStatement(DimanaParser.ForStatementContext ctx) {
      ST st = group.getInstanceOf("forStatement");
      String var = ctx.ID().getText();
      int  value = Integer.parseInt(ctx.INT().getText());
      String max = ctx.expr().getText();
      String init = var+" = "+value;
      String condition = var+" <= "+max;
      String increment = var+"++";
      st.add("init", init);
      st.add("condition", condition);
      st.add("increment", increment);

      List<ST> bodies = new ArrayList<>();
      for (int i = 0; i < ctx.instruction().size(); i++) {
         ST body = visit(ctx.instruction(i));
         bodies.add(body);
      }
      st.add("body", bodies);
      return st;
   }

   @Override public ST visitIndexExpr(DimanaParser.IndexExprContext ctx) {
      ST st = group.getInstanceOf("IndexExpr");
      String e1 = ctx.ID().getText();
      ST e2 = visit(ctx.expr());

      st.add("e1", e1);
      st.add("e2", e2);
      return st;
   }

   @Override public ST visitStringExpr(DimanaParser.StringExprContext ctx) {
      ST st = group.getInstanceOf("StringExpr");
      String e1 = ctx.STRING().getText();

      st.add("e1", e1);
      return st;
   }

   @Override public ST visitUnaryExpr(DimanaParser.UnaryExprContext ctx) {
      ST e = visit(ctx.expr());
      ST st ;
      st = group.getInstanceOf("unary");

      if(ctx.op.getText().equals("-")){
         st.add("e",e);
         return st;
      }
      else{
         st.add("e",e);
         return st;
      }
   }

   @Override public ST visitIntExpr(DimanaParser.IntExprContext ctx) {
      ST st = group.getInstanceOf("IntExpr");
      String e1 = ctx.INT().getText();

      st.add("e1", e1);
      return st;
   }

   @Override public ST visitConvExpr(DimanaParser.ConvExprContext ctx) {
      //String var = ctx.ID().getText();
      //ST st = group.getInstanceOf("conv");
      //ST e1 = visit(ctx.expr());
      //   
      //st.add("var", var);
      //st.add("e1", e1.render());
      //return st;

      String var = ctx.ID().getText();
      ST st = group.getInstanceOf("conv");
      
      if (ctx.expr() instanceof DimanaParser.StringExprContext) {
         System.out.println("STRING");
          String stringValue = ctx.expr().getText();
          st.add("e1", stringValue);
      } else {
          ST e1 = visit(ctx.expr());
          st.add("e1", e1.render());
      }
      
      st.add("var", var);
      
      if (ctx.INT() != null) {
          String intValue = ctx.INT().getText();
          st.add("intValue", intValue);
      }
      
      return st;
   }

   @Override public ST visitRealExpr(DimanaParser.RealExprContext ctx) {
      ST st = group.getInstanceOf("RealExpr");
      String e1 = ctx.REAL().getText();

      st.add("e1", e1);
      return st;
   }

   @Override public ST visitReadExpr(DimanaParser.ReadExprContext ctx) {
      // String e1 = ctx.expr().getText();
      // ST st = group.getInstanceOf("read");
      
      // st.add("e1", e1);
      // return st;
      String e1 = ctx.expr().getText();
      ST st = group.getInstanceOf("read");
      st.add("e1", e1);
      return st;
   }

   @Override public ST visitMulDivExpr(DimanaParser.MulDivExprContext ctx) {
      ST e1 = visit(ctx.expr(0));
      ST e2 = visit(ctx.expr(1));
      ST st;

      if(ctx.op.getText().equals("*")){
         st = group.getInstanceOf("mul");
      }
      else{
         st = group.getInstanceOf("div");
      }

      st.add("e1", e1);
      st.add("e2", e2);
      
      return st;
   }

   @Override public ST visitSumSubExpr(DimanaParser.SumSubExprContext ctx) {
      ST e1 = visit(ctx.expr(0));
      ST e2 = visit(ctx.expr(1));
      ST st;

      if(ctx.op.getText().equals("+")){
         st = group.getInstanceOf("sum");
      }
      else{
         st = group.getInstanceOf("sub");
      }

      st.add("e1", e1);
      st.add("e2", e2);

      return st;
   }

   @Override public ST visitParenExpr(DimanaParser.ParenExprContext ctx) {
      return visit(ctx.expr());
   }

   @Override public ST visitIdExpr(DimanaParser.IdExprContext ctx) {
      ST st = group.getInstanceOf("var_name");
      st.add("name", ctx.ID().getText());
      return st;
   }

   @Override public ST visitAssignExpr(DimanaParser.AssignExprContext ctx) {
      String var = ctx.ID().getText(); // Obtém o texto do primeiro nó ID da lista
      ST st = group.getInstanceOf("assign");
      //ST value = visit(ctx.expr());


      if (ctx.expr() instanceof DimanaParser.IntExprContext) {
         System.out.println("INT");
          int intValue = Integer.parseInt(ctx.expr().getText());
          st.add("value", intValue);
      } else {
          ST e = visit(ctx.expr());
          st.add("value", e.render());
      }
      //System.out.println("value: " + value);

      st.add("var", var);
      //st.add("value", value);

      System.out.println(st.render());
      return st;
   }

   @Override public ST visitListExpr(DimanaParser.ListExprContext ctx) {
      String tp =  ctx.ID(0).getText();
      String var = ctx.ID(1).getText();
      ST st = group.getInstanceOf("assignArray");
      if (tp.equals("string")){
         st.add("tp", "String");
      } else if (tp.equals("int")){
         st.add("tp", "int");
      } else if (tp.equals("real")){
         st.add("tp", "double");
      }else{
         st.add("tp", tp);
      }
      
      st.add("var", var);
      return st;
   }

   @Override public ST visitListAddExpr(DimanaParser.ListAddExprContext ctx) {
      ST var = visit(ctx.expr());
      ST st = group.getInstanceOf("assignArrayAdd");
      String value = ctx.ID().getText();
      st.add("var", var);
      st.add("value", value);
      return st;
   }
}
