#!/bin/bash
javac *.java 