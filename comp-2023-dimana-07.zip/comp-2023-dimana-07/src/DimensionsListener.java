// Generated from Dimensions.g4 by ANTLR 4.9.3
import java.util.HashMap;
import java.util.ArrayList;
import java.util.List;

import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link DimensionsParser}.
 */
public interface DimensionsListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link DimensionsParser#program}.
	 * @param ctx the parse tree
	 */
	void enterProgram(DimensionsParser.ProgramContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionsParser#program}.
	 * @param ctx the parse tree
	 */
	void exitProgram(DimensionsParser.ProgramContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionsParser#instruction}.
	 * @param ctx the parse tree
	 */
	void enterInstruction(DimensionsParser.InstructionContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionsParser#instruction}.
	 * @param ctx the parse tree
	 */
	void exitInstruction(DimensionsParser.InstructionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code dimensionSi}
	 * labeled alternative in {@link DimensionsParser#dimension}.
	 * @param ctx the parse tree
	 */
	void enterDimensionSi(DimensionsParser.DimensionSiContext ctx);
	/**
	 * Exit a parse tree produced by the {@code dimensionSi}
	 * labeled alternative in {@link DimensionsParser#dimension}.
	 * @param ctx the parse tree
	 */
	void exitDimensionSi(DimensionsParser.DimensionSiContext ctx);
	/**
	 * Enter a parse tree produced by the {@code dimensionDependant}
	 * labeled alternative in {@link DimensionsParser#dimension}.
	 * @param ctx the parse tree
	 */
	void enterDimensionDependant(DimensionsParser.DimensionDependantContext ctx);
	/**
	 * Exit a parse tree produced by the {@code dimensionDependant}
	 * labeled alternative in {@link DimensionsParser#dimension}.
	 * @param ctx the parse tree
	 */
	void exitDimensionDependant(DimensionsParser.DimensionDependantContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionsParser#prefix}.
	 * @param ctx the parse tree
	 */
	void enterPrefix(DimensionsParser.PrefixContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionsParser#prefix}.
	 * @param ctx the parse tree
	 */
	void exitPrefix(DimensionsParser.PrefixContext ctx);
	/**
	 * Enter a parse tree produced by {@link DimensionsParser#unit}.
	 * @param ctx the parse tree
	 */
	void enterUnit(DimensionsParser.UnitContext ctx);
	/**
	 * Exit a parse tree produced by {@link DimensionsParser#unit}.
	 * @param ctx the parse tree
	 */
	void exitUnit(DimensionsParser.UnitContext ctx);
	/**
	 * Enter a parse tree produced by the {@code notacaodez}
	 * labeled alternative in {@link DimensionsParser#notacao}.
	 * @param ctx the parse tree
	 */
	void enterNotacaodez(DimensionsParser.NotacaodezContext ctx);
	/**
	 * Exit a parse tree produced by the {@code notacaodez}
	 * labeled alternative in {@link DimensionsParser#notacao}.
	 * @param ctx the parse tree
	 */
	void exitNotacaodez(DimensionsParser.NotacaodezContext ctx);
	/**
	 * Enter a parse tree produced by the {@code notacaocienfitica}
	 * labeled alternative in {@link DimensionsParser#notacao}.
	 * @param ctx the parse tree
	 */
	void enterNotacaocienfitica(DimensionsParser.NotacaocienfiticaContext ctx);
	/**
	 * Exit a parse tree produced by the {@code notacaocienfitica}
	 * labeled alternative in {@link DimensionsParser#notacao}.
	 * @param ctx the parse tree
	 */
	void exitNotacaocienfitica(DimensionsParser.NotacaocienfiticaContext ctx);
}