# Tema **DimAna**, grupo **dimana-07**
-----

## Constituição dos grupos e participação individual global

| NMec | Nome | email | Participação |
|:---:|:---|:---|:---:|
| 107876 | GABRIEL MELO TEIXEIRA | gabrielm.teixeira@ua.pt | 16.6% |
| 108133 | GONÇALO FRANCISCO COUTO SOUSA | gfcs@ua.pt | 16.6% |
| 103896 | GUILHERME ALEXANDRE SIMÕES LOPES | gui.lopes@ua.pt | 16.6% |
| 104429 | JOANA AMARAL GOMES | joanaagomes@ua.pt | 16.6% |
| 107548 | LIA RIBEIRO DE LIMA CARDOSO | lia.cardoso@ua.pt | 16.6% |
| 102383 | VÂNIA INÊS MAGALHÃES MORAIS | vania.morais@ua.pt | 16.6% |

## Estrutura do repositório

- **src** - contém todo o código fonte do projeto e ficheiros bash.

- **doc** -- contém toda a documentação adicional a este README.

- **examples** -- contém os exemplos ilustrativos das linguagens criadas.

    - Estes exemplos contêm comentários (no formato aceite pelas linguagens),
      que os tornem auto-explicativos.

## Como correr
- Caso os script bash não corram corretamente, fazer:
``
javac *.java 
java DimanaMain <exemplo>
``

## Relatório

### Objetivo 
- O objetivo deste projeto é desenvolver uma linguagem de programação compilada que permita o uso de análise dimensional em expressões numéricas. A análise dimensional é uma técnica usada para verificar a consistência 
de equações físicas e pode ser aplicada a outras áreas que usam quantidades numéricas para representar coisas diferentes. O sistema de tipos da linguagem será estendido para permitir a definição de dimensões distintas 
para expressões numéricas e validar a sua correção.

A linguagem desenvolvida implementa todas as características mínimas definidas para o projeto, sendo estas:
  - Instruções para definir uma nova dimensão, ambas de forma independente e dependente, sendo que na segunda forma, a nova dimensão é definida através da utilização de uma expressão aritmética envolvendo multiplicações ou divisões de dimensões existentes. Em qualquer das formas, a dimensão funciona como um novo tipo de dados numéricos. A definição de uma dimensão envolve também a definição da sua unidade base e, um sufixo, se necessário.
  - Instrução para definir outra unidade para um dimensão existente.
  - Os tipos de dados: 
      ‣ inteiro, 
      ‣ real, 
      ‣ string,
      ‣ lista.
  - Aceitação de expressões aritméticas standard para os tipos de dados numéricos. Aceita também a operação de concatenação de texto.
  - Instrução de escrita no standard output.
  - Instrução de leitura de texto a partir do standard input.
  - Operadores de conversão entre tipos de dados.
  - Instrução para adicionar elemento no fim de uma lista.
  - Operadores para aceder a elementos de uma lista.
  - Instrução de iteração entre dois valores inteiros.
  - Instrução estática (isto é, apenas com significado em tempo de compilação) para incluir o conteúdo de outro ficheiro.
  - Verificação semântica do sistema de tipos com análise dimensional.

Implementa também as seguintes características desejáveis:
  - Permitir a definição de valores dimensionais literais com sufixo.
  - Instrução prefixa e aplicação de prefixos nos valores literais.

## Contribuições

- **GABRIEL MELO TEIXEIRA** - gramática principal e secundária, templates
- **GONÇALO FRANCISCO COUTO SOUSA** - gramática principal e secundária, ficheiros bash e documentação
- **GUILHERME ALEXANDRE SIMÕES LOPES** - gramática principal e secundária, análise semântica secundária
- **JOANA AMARAL GOMES** -gramática principal e secundária, documentação
- **LIA RIBEIRO DE LIMA CARDOSO** -gramática principal e secundária, templates e análise semântica principal
- **VÂNIA INÊS MAGALHÃES MORAIS** - gramática principal e secundária, templates e análise semântica principal

